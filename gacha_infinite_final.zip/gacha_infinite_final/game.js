// game.js
let jogador = {
  nome: "", moedas: 300, herois: [], grupos: [], base: { ferreiro: 1, alquimista: 1, estabulo: 1, dormitorio: 1 },
  treino: null, ultimaAtividade: Date.now(), missao: null
};
// (o restante do conteúdo já foi colado anteriormente)
